<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TypeMaterial extends Model
{
    protected $fillable = [
        'name', 'sid'
    ];
}
