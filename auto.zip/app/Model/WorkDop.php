<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class WorkDop extends Model
{
    protected $fillable = ['name', 'price', 'sid', 'type'];
}
